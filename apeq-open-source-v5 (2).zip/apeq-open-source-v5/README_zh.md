# APEQ V5 开源代码整理包

本目录收齐当前 TDSC 稿件所用的协议实现、比较基线适配器、实验执行器、审计和绘图脚本。上一版目录及原有实验记录保持不变。

- 代码结构和依赖见根目录 `README.md`。
- 论文与代码对应关系见 `docs/PAPER_TO_CODE.md`。
- E1/E3 新实验、后台运行、PowerShell 监视，以及直接分析已有数据的命令见 `reproduction/README.md`。
- 历史 E1 与 E3 使用不同冻结源码，对应哈希、驱动副本和执行器保存在 `provenance/`，不要混用两个版本或将新测量标成旧数据。

本包只整理代码、文档及必要的来源元数据。没有打包原始测量、私有输入 CSV、实验日志、抓包、编译产物、PPT 或论文。输入是合成实验数据，但仍应随独立数据归档发布，避免与源码混在一起。

运行 `python3 -B tools/verify_source_release.py` 可验证源码清单。短校验不会启动 Docker 长实验。`run_application_v5.py run` 与 `run_sequence_v5.py run` 才会开始正式采集；它们保留固定样本数、冻结检查和失败即停止的策略。

代码仓库：`https://github.com/anonymous/apeq-artifact`。这是本地发布目录，尚未上传到公共仓库。项目许可证仍待作者选择；Lu 上游源码没有随包分发，需按 `apeq-lu-eq/SOURCE.md` 独立下载。自有代码的最终许可证不能替代第三方组件的许可。

本次不重新运行已完成的 E1/E3 性能实验。已完成数据的分析使用独立输出目录验证，不覆盖原始记录。
